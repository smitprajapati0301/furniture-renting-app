import React, { useState } from 'react';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Sample furniture data (replace with actual data from API or database)
  const furnitureData = [
    {
      name: 'Modern Table',
      image: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fpngtree.com%2Ffree-furniture-png&psig=AOvVaw2FnBNpDeErwY2r7aRUgOkz&ust=1719747320567000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCKiY-5TcgIcDFQAAAAAdAAAAABAE',
      price: 100,
      category: 'Table',
      rating: 4.5,
    },
    {
      name: 'Comfortable Chair',
      image: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pixelsquid.com%2Fpng%2Fsquare-outdoor-plastic-table-2735944507378898490&psig=AOvVaw2FnBNpDeErwY2r7aRUgOkz&ust=1719747320567000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCKiY-5TcgIcDFQAAAAAdAAAAABAc',
      price: 80,
      category: 'Chair',
      rating: 4.2,
    },
    {
      name: 'Cozy Bed',
      image: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pixelsquid.com%2Fpng%2Fsquare-outdoor-plastic-table-2735944507378898490&psig=AOvVaw2FnBNpDeErwY2r7aRUgOkz&ust=1719747320567000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCKiY-5TcgIcDFQAAAAAdAAAAABAc',
      price: 200,
      category: 'Bed',
      rating: 4.8,
    },
    {
      name: 'Elegant Sofa',
      image: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pixelsquid.com%2Fpng%2Fsquare-outdoor-plastic-table-2735944507378898490&psig=AOvVaw2FnBNpDeErwY2r7aRUgOkz&ust=1719747320567000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCKiY-5TcgIcDFQAAAAAdAAAAABAc',
      price: 300,
      category: 'Sofa',
      rating: 4.9,
    },
  ];

  const handleSearch = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleCategoryChange = (e) => {
    setSelectedCategory(e.target.value);
  };

  const filteredFurniture = furnitureData.filter(item =>
    (selectedCategory === 'All' || item.category === selectedCategory) &&
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div style={styles.app}>
      <header style={styles.header}>
        <h1 style={styles.headerTitle}>Furnicom</h1>
        <div style={styles.searchBar}>
          <input
            type="text"
            value={searchQuery}
            onChange={handleSearch}
            placeholder="Search furniture..."
            style={styles.searchInput}
          />
          <select value={selectedCategory} onChange={handleCategoryChange} style={styles.categorySelect}>
            <option value="All">All</option>
            <option value="Table">Table</option>
            <option value="Chair">Chair</option>
            <option value="Bed">Bed</option>
            <option value="Sofa">Sofa</option>
          </select>
        </div>
      </header>
      <main style={styles.main}>
        <div style={styles.furnitureContainer}>
          {filteredFurniture.map((item, index) => (
            <div key={index} style={styles.furnitureCard}>
              <img src={item.image} alt={item.name} style={styles.furnitureImage} />
              <div style={styles.furnitureDetails}>
                <h2 style={styles.furnitureName}>{item.name}</h2>
                <p style={styles.furniturePrice}>${item.price.toLocaleString()} per month</p>
                <div style={styles.furnitureRating}>
                  Rating: {item.rating}
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

const styles = {
  app: {
    textAlign: 'center',
    fontFamily: 'Arial, sans-serif',
  },
  header: {
    backgroundColor: '#000',
    color: '#fff',
    padding: '20px',
  },
  headerTitle: {
    margin: 0,
    fontSize: '24px',
  },
  searchBar: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: '10px',
  },
  searchInput: {
    padding: '10px',
    marginRight: '10px',
    borderRadius: '5px',
    border: 'none',
  },
  categorySelect: {
    padding: '10px',
    borderRadius: '5px',
    border: 'none',
    backgroundColor: '#fff',
    cursor: 'pointer',
  },
  main: {
    height: 'calc(100vh - 150px)', // Adjust height as needed
    overflowY: 'scroll',
  },
  furnitureContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
    padding: '20px',
  },
  furnitureCard: {
    backgroundColor: '#f0f0f0',
    borderRadius: '10px',
    margin: '10px',
    padding: '20px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
    width: '250px',
  },
  furnitureImage: {
    width: '100%',
    borderRadius: '10px',
  },
  furnitureDetails: {
    marginTop: '10px',
  },
  furnitureName: {
    fontSize: '18px',
    margin: '5px 0',
  },
  furniturePrice: {
    color: '#888',
    margin: '5px 0',
  },
  furnitureRating: {
    color: '#666',
  },
  footer: {
    backgroundColor: '#333',
    color: '#fff',
    padding: '10px',
    position: 'fixed',
    bottom: 0,
    width: '100%',
  },
};

export default App;

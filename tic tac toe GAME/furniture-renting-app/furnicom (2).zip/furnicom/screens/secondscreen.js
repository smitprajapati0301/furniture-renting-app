import React, { Component } from 'react';
import {
  View,
  TextInput,
  TouchableOpacity,
  Text,
  StyleSheet,
  Alert,
} from 'react-native';

export default class Secondscreen extends Component {
  gotoaction = () => {
    this.props.navigation.navigate('Action');
  };

  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Registration</Text>
        <TextInput
          style={styles.input}
          placeholder="First Name"
          onChangeText={(text) => this.setState({ firstName: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="Last Name"
          onChangeText={(text) => this.setState({ lastName: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="House Number"
          onChangeText={(text) => this.setState({ houseNumber: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="City"
          onChangeText={(text) => this.setState({ city: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="District"
          onChangeText={(text) => this.setState({ district: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="State"
          onChangeText={(text) => this.setState({ state: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="Country"
          onChangeText={(text) => this.setState({ country: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="Phone Number"
          onChangeText={(text) => this.setState({ phoneNumber: text })}
          keyboardType="phone-pad"
        />
        <TouchableOpacity style={styles.button} onPress={this.gotoaction}>
          <Text style={styles.buttonText}>Submit</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'white',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 15,
    paddingHorizontal: 10,
  },
  button: {
    width: '80%',
    height: 50,
    backgroundColor: 'black',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    marginBottom: 20,
  },
  buttonText: {
    color: 'white',
    fontSize: 20,
  },
});

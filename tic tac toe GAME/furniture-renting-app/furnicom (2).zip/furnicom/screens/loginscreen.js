import React, { Component } from 'react';
import {
  View,
  TextInput,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
} from 'react-native';

export default class HomeScreen extends Component {
  gotoSecondScreen = () => {
    this.props.navigation.navigate('Secondscreen');
  };

  gotoSignupScreen = () => {
    this.props.navigation.navigate('SignupScreen');
  };

  render() {
    return (
      <View style={styles.bg}>
        <Image source={require('./furniture.jpg')} style={styles.M} />

        <Text style={styles.welcomeText}>
          Welcome to <Text style={styles.italic}>FURNICOM</Text>, your ultimate destination for discovering, designing, and delighting in the perfect furniture for your home!
        </Text>

        <Text style={styles.loginText}>
          Login
        </Text>

        <View style={styles.Emailbd}>
          <TextInput
            style={styles.Email}
            placeholder="Email"
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <TextInput
            style={styles.Password}
            placeholder="Password"
            secureTextEntry
          />
          <TouchableOpacity
            style={styles.Button}
            onPress={this.gotoSecondScreen}>
            <Text style={styles.ButtonText}>Login</Text>
          </TouchableOpacity>

          <View style={styles.Sign}>
            <Text style={styles.signText}>Have you not account?</Text>
            <TouchableOpacity onPress={this.gotoSignupScreen}>
              <Text style={styles.signUpText}>Sign up</Text>
            </TouchableOpacity>
          </View>          
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  bg: {
    backgroundColor: 'white',
    height: '100%',
  },
  M: {
    height: 150,
    width: 100,
    alignSelf: 'center',
    marginVertical: 20,
  },
  welcomeText: {
    textAlign: 'center',
    fontWeight: 'bold',
    marginHorizontal: 20,
  },
  italic: {
    fontStyle: 'italic',
  },
  loginText: {
    textAlign: 'center',
    fontSize: 30,
    textShadowRadius: 20,
    marginTop: 20,
  },
  Emailbd: {
    alignItems: 'center',
    marginTop: 40,
  },
  Email: {
    height: 40,
    width: '80%',
    borderColor: 'black',
    borderWidth: 2,
    padding: 10,
    borderRadius: 5,
    backgroundColor: 'white',
    marginBottom: 20,
  },
  Password: {
    height: 40,
    width: '80%',
    borderColor: 'black',
    borderWidth: 2,
    padding: 10,
    borderRadius: 5,
    backgroundColor: 'white',
    marginBottom: 20,
  },
  Button: {
    height: 50,
    width: '80%',
    backgroundColor: 'black',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginTop: 20,
  },
  ButtonText: {
    fontSize: 20,
    color: 'white',
  },
  Sign: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
  },
  signText: {
    textAlign: 'center',
  },
  signUpText: {
    color: 'blue',
    marginLeft: 5,
  },
});

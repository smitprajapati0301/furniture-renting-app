import React, {Component} from 'react';
import {Button,View,Text,StyleSheet,TouchableOpacity,Image} from 'react-native';
import Loginscreen from './screens/loginscreen'
import Secondscreen from './screens/secondscreen'
import Action from './screens/action'
import SignupScreen from './screens/SignupScreen'
/*import {NavigationContainer} from '@react-navigation/native'
import {createNativeStackNavigator} from '@react-navigation/stack'*/
import {createAppContainer,createSwitchNavigator} from 'react-navigation';



export default class App extends Component
{
  render(){
    return(
        <View>
      
      
     <AppContainer/>
      
      
      
      </View>    

    );
  }
}


var AppNavigation=createSwitchNavigator({
  Loginscreen:Loginscreen,
  SignupScreen:SignupScreen,
  Secondscreen:Secondscreen,
  Action:Action,
  
})
const AppContainer=createAppContainer(AppNavigation)






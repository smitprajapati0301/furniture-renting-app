import React, { useRef } from 'react';

const SmoothScrollContainer = () => {
  const containerRef = useRef(null);

  const scrollDown = () => {
    containerRef.current.scrollBy({ top: 100, behavior: 'smooth' });
  };

  return (
    <div>
      <button onClick={scrollDown}>Scroll Down</button>
      <div
        ref={containerRef}
        style={{
          height: '400px',
          overflowY: 'scroll',
          scrollBehavior: 'smooth', // CSS for smooth scrolling
          border: '1px solid black'
        }}
      >
        <div style={{ height: '800px' }}>Some scrollable content</div>
      </div>
    </div>
  );
};

export default SmoothScrollContainer;

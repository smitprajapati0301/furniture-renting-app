import React, { Component } from 'react';

import { View, StyleSheet, Text, TouchableOpacity } from 'react-native';
import { Audio } from 'expo-av';

export default class SoundButton extends Component {
  async playSound() {
    await Audio.Sound.createAsync(
      { uri: 'https://soundbible.com/mp3/service-bell_daniel_simion.mp3' },
      { shouldPlay: true }
    );
  }
  render() {
    return (
      <TouchableOpacity style={[styles.soundbtn, {backgroundColor: this.props.bgColor}]} onPress={this.playSound}>
        {' '}
        <Text style={styles.soundtext}> Play Sound </Text>{' '}
      </TouchableOpacity>
    );
  }
}

const styles = StyleSheet.create({
  soundbtn: {
    margin: 50,
    backgroundColor: 'pink',
    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
    color: 'white',
    borderRadius: 8,
  },
  soundtext: {
    color: 'white',
    fontSize: 30,
  },
});

import React, {Component} from 'react';
import {Button,View,Text,StyleSheet,TouchableOpacity,Image} from 'react-native';

export default class App extends React.Component
{
  render(){
    return(
      <View>
      <Text style={styles.navbar}>Movieflix</Text>
      </View>
    );
  }
}

const  styles = StyleSheet.create({

  navbar:{
    backgroundColor:'#B03A2E',
    
  }
});
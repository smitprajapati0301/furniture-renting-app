import React, {Component} from 'react';
import {Button,View,Text,StyleSheet,TouchableOpacity,Image} from 'react-native';

export default class App extends React.Component
{
  render(){
    return(
      <View>
        <TouchableOpacity style>
           smit
        </TouchableOpacity>
      </View>
    );
  }
}


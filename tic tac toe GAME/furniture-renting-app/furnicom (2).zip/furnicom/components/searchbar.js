import React, {Component} from 'react';
import {Button,View,Text,StyleSheet,TouchableOpacity,Image,TextInput} from 'react-native';

export default function Search()
{
    return(
      <View>

      <div style={styles.Sb}>
         <TextInput placeholder='Type to search...' style={styles.Searchbar}></TextInput>
      </div>

      </View>
    );
  }


const  styles = StyleSheet.create({

  Searchbar:{
    borderWidth:'3px',
    borderRadius:'20px',
    marginTop:'10px',
    width:'330px',
    textAlign:'center'
    

  },

  Sb:{
    
    borderColor:'black',
    
    
    
  }
});